﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2___Calculator___Csharp
{
    //Laura Malcervelli
    //Project 2 - Calculator C#
    //2/9/22
    public partial class Form1 : Form
    {
        bool operatorClicked = true;
        double firstNumber = 0;
        String operatorSign;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            txtResult.Select();
            txtResult.Text = "0";
            operatorClicked = true;
        }

        private void btnOff_Click(object sender, EventArgs e)
        {
            this.Close();  
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "9";
            else
                txtResult.Text += "9";
            operatorClicked = false;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "8";
            else
                txtResult.Text += "8";
            operatorClicked = false;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "7";
            else
                txtResult.Text += "7";
            operatorClicked = false;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "6";
            else
                txtResult.Text += "6";
            operatorClicked = false;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "5";
            else
                txtResult.Text += "5";
            operatorClicked = false;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "4";
            else
                txtResult.Text += "4";
            operatorClicked = false;
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "3";
            else
                txtResult.Text += "3";
            operatorClicked = false;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "2";
            else
                txtResult.Text += "2";
            operatorClicked = false;
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "1";
            else
                txtResult.Text += "1";
            operatorClicked = false;
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = "0";
            else
                txtResult.Text += "0";
            operatorClicked = false;
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            if (operatorClicked)
                txtResult.Text = ".";
            if (!txtResult.Text.Contains("."))
                 txtResult.Text += "."; 

            operatorClicked = false;
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            double secondNumber = Convert.ToDouble(txtResult.Text);

            switch (operatorSign)
            {
                case "+":
                    txtResult.Text = Convert.ToString(firstNumber + secondNumber);
                    break;
                case "-":
                    txtResult.Text = Convert.ToString(firstNumber - secondNumber);
                    break;
                case "*":
                    txtResult.Text = Convert.ToString(firstNumber * secondNumber);
                    break;
                case "/":
                    txtResult.Text = Convert.ToString(firstNumber / secondNumber);
                    break;
            }
            operatorClicked = true;
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            operatorClicked = true;
            operatorSign = "+";
            firstNumber = double.Parse(txtResult.Text);
            

        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            operatorClicked = true;
            operatorSign = "-";
            firstNumber = double.Parse(txtResult.Text);
         
        }

        private void btnTimes_Click(object sender, EventArgs e)
        {
            operatorClicked = true;
            operatorSign = "*";
            firstNumber = double.Parse(txtResult.Text);
            
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            operatorClicked = true;
            operatorSign = "/";
            firstNumber = double.Parse(txtResult.Text);
            
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            txtResult.Text = "0";
            operatorClicked = true;
        }

        private void offToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtResult.Text);
        }

        private void offToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
